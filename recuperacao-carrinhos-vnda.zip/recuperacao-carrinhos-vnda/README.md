# Projeto: Recuperação de Carrinhos Abandonados via WhatsApp + Vnda

Este projeto automatiza a recuperação de carrinhos abandonados da plataforma Vnda e envia mensagens via WhatsApp para os clientes.
